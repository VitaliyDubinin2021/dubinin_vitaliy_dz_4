"""

Task 4

"""

import utilts

print(utilts.currency_rates('USD'), 'текущий курс американского доллара') # Доллар американский (по заданию)
print(utilts.currency_rates('EUR'), 'текущий курс евро') # Евро (по заданию)
print(utilts.currency_rates('AZN'), 'текущий курс азербайджанского маната') # Для примера - азербайджанский манат
print(utilts.currency_rates('CAD'), 'текущий курс канадского доллара') # Для примера - канадский доллар
print(utilts.currency_rates('CNY'), 'текущий курс китайского юаня') # Для примера - китайский юань
print(utilts.currency_rates('NOK'), 'текущий курс норвежского крона') # Для примера - норвежский крон
print(utilts.currency_rates('BYN'), 'текущий курс белорусского рубля') # Для примера - белорусский рубль
print(utilts.currency_rates('BRL'), 'текущий курс бразильского реала') # Для примера - бразильский реал
print(utilts.currency_rates('INR'), 'текущий курс индийского рупия') # Для примера - индийский рупий
print(utilts.currency_rates('SGD'), 'текущий курс сингапурского доллара') # Для примера - сингапурский доллар
print(utilts.currency_rates('TRY'), 'текущий курс турецкого лира') # Для примера - турецкий лир
print(utilts.currency_rates('JPY'), 'текущий курс японского иена') # Для примера - японский иен
print(utilts.currency_rates('CHF'), 'текущий курс швейцарского франка') # Для примера - швейцарский франк